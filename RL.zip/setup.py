# setup.py
from setuptools import setup

setup(
    name='RL',
    version='0.1.0',
    packages=['RL'],
)