from .base_critic import BaseCritic
from torch import nn
from torch import optim
import numpy as np
from RL.infrastructure import pytorch_util as ptu
from RL.infrastructure import sac_utils
import torch

class SACCritic(nn.Module, BaseCritic):
    """
    
        ob - observation
        ac - action
        _no - this tensor should have shape (batch self.size /n/, observation dim)
        _na - this tensor should have shape (batch self.size /n/, action dim)
        _n  - this tensor should have shape (batch self.size /n/)

        Note: batch self.size /n/ is defined at runtime.
        is None
    """
    def __init__(self, hparams):
        super(SACCritic, self).__init__()
        self.ob_dim = hparams['ob_dim']
        self.ac_dim = hparams['ac_dim']
        self.discrete = hparams['discrete']
        self.size = hparams['size']
        self.n_layers = hparams['n_layers']
        self.learning_rate = hparams['learning_rate']

        # critic parameters
        self.gamma = hparams['gamma']
        self.Q1 = ptu.build_mlp(
            self.ob_dim + self.ac_dim,
            1,
            n_layers=self.n_layers,
            size=self.size,
            activation='relu'
        )
        self.Q2 = ptu.build_mlp(
            self.ob_dim + self.ac_dim,
            1,
            n_layers=self.n_layers,
            size=self.size,
            activation='relu'
        )
        self.Q1.to(ptu.device)
        self.Q2.to(ptu.device)
        self.loss = nn.MSELoss()

        self.optimizer = optim.Adam(
            self.parameters(),
            self.learning_rate,
        )

    def forward(self, obs: torch.Tensor, action: torch.Tensor):
        # return the two q values
        input_pair = torch.cat((obs, action), dim = 1)
        val1 = self.Q1(input_pair)
        val2 = self.Q2(input_pair)
        values = [val1, val2]
        return values



        